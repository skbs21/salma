To launch te website use 

npx tailwindcss --postcss -i ./src/styles/style.scss -o ./dist/style.css
